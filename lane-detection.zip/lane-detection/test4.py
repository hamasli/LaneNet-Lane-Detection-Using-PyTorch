import os
import torch
from model.lanenet.LaneNet import LaneNet
from torchvision import transforms
import numpy as np
from PIL import Image
import cv2

# Set the device for computation
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def load_frame(frame, transform):
    # Convert the frame from BGR to RGB
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # Convert to PIL Image
    pil_img = Image.fromarray(frame_rgb)
    # Apply transformations
    img_transformed = transform(pil_img)
    return img_transformed

def nothing():
    pass;

def process_video(video_path, model_path, resize_height, resize_width):
    # ... [Setup and model loading code]
    output_dir = 'test_output'
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    # Define image transformations
    data_transform = transforms.Compose([
        transforms.Resize((resize_height, resize_width)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # Load model
    model = LaneNet(arch='ENet')  # Adjust if needed
    state_dict = torch.load(model_path, map_location=DEVICE, weights_only=True)
    model.load_state_dict(state_dict)
    model.eval()
    model.to(DEVICE)

    # Open video file
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Unable to open video file {video_path}")
        return

    # Get video properties
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    # Define the codec and create VideoWriter objects for various outputs
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    
    output_video_path = os.path.join(output_dir, 'output_video.avi')
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (frame_width, frame_height))

    instance_output_path = os.path.join(output_dir, 'instance_output_video.avi')
    out_instance = cv2.VideoWriter(instance_output_path, fourcc, fps, (frame_width, frame_height))

    binary_output_path = os.path.join(output_dir, 'binary_output_video.avi')
    out_binary = cv2.VideoWriter(binary_output_path, fourcc, fps, (frame_width, frame_height), isColor=False)

    # Create a window and a trackbar for threshold adjustment
    cv2.namedWindow('Binary Output')
    cv2.createTrackbar('Threshold', 'Binary Output', 127, 255, nothing);

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Prepare the frame
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        dummy_input = load_frame(frame_rgb, data_transform).unsqueeze(0).to(DEVICE)

        # Perform inference
        with torch.no_grad():
            outputs = model(dummy_input)

        # Process the output
        instance_pred = torch.squeeze(outputs['instance_seg_logits'].detach().to('cpu')).numpy()
        binary_pred = torch.squeeze(outputs['binary_seg_pred']).detach().to('cpu').numpy()

        # Convert predictions to images
        instance_pred_img = (instance_pred * 255).astype(np.uint8)
        binary_pred_img = (binary_pred * 255).astype(np.uint8)  # Single-channel binary prediction

        # Resize instance_pred_img to match frame size
        instance_pred_img_resized = cv2.resize(instance_pred_img.transpose((1, 2, 0)), (frame_width, frame_height), interpolation=cv2.INTER_LINEAR)
        if len(instance_pred_img_resized.shape) == 3 and instance_pred_img_resized.shape[2] != 1:
            instance_pred_img_resized = cv2.cvtColor(instance_pred_img_resized, cv2.COLOR_BGR2GRAY)
        if len(instance_pred_img_resized.shape) == 2:
            instance_pred_img_rgb = cv2.applyColorMap(instance_pred_img_resized, cv2.COLORMAP_JET)
        else:
            instance_pred_img_rgb = instance_pred_img_resized

        # Get the current threshold from the trackbar
        threshold = cv2.getTrackbarPos('Threshold', 'Binary Output')

        # Apply the threshold
        _, binary_pred_img_thresholded = cv2.threshold(binary_pred_img, threshold, 255, cv2.THRESH_BINARY)
        binary_pred_img_resized = cv2.resize(binary_pred_img_thresholded, (frame_width, frame_height), interpolation=cv2.INTER_NEAREST)

        # Display the binary output with adjustable threshold
       

        # Overlay results on the original frame
        result = cv2.addWeighted(frame, 0.7, instance_pred_img_rgb, 0.3, 0)
        
        cv2.imshow('Binary Output', binary_pred_img_resized);
        cv2.imshow("result",result);
        cv2.imshow("instance",instance_pred_img_resized)
        # Write the frames to the output videos
        out.write(result)
        out_instance.write(instance_pred_img_resized)
        out_binary.write(binary_pred_img_resized)

        # Break if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    out.release()
    out_instance.release()
    out_binary.release()
    cv2.destroyAllWindows()

    # ... [Setup and model loading code]
    output_dir = 'test_output'
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    # Define image transformations
    data_transform = transforms.Compose([
        transforms.Resize((resize_height, resize_width)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # Load model
    model = LaneNet(arch='ENet')  # Adjust if needed
    state_dict = torch.load(model_path, map_location=DEVICE, weights_only=True)
    model.load_state_dict(state_dict)
    model.eval()
    model.to(DEVICE)

    # Open video file
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Unable to open video file {video_path}")
        return

    # Get video properties
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    # Define the codec and create VideoWriter objects for various outputs
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    
    output_video_path = os.path.join(output_dir, 'output_video.avi')
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (frame_width, frame_height))

    instance_output_path = os.path.join(output_dir, 'instance_output_video.avi')
    out_instance = cv2.VideoWriter(instance_output_path, fourcc, fps, (frame_width, frame_height))

    binary_output_path = os.path.join(output_dir, 'binary_output_video.avi')
    out_binary = cv2.VideoWriter(binary_output_path, fourcc, fps, (frame_width, frame_height), isColor=False)

    # Define a list of thresholds to test
    thresholds = [50, 100, 150, 200]

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Prepare the frame
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        dummy_input = load_frame(frame_rgb, data_transform).unsqueeze(0).to(DEVICE)

        # Perform inference
        with torch.no_grad():
            outputs = model(dummy_input)

        # Process the output
        instance_pred = torch.squeeze(outputs['instance_seg_logits'].detach().to('cpu')).numpy()
        binary_pred = torch.squeeze(outputs['binary_seg_pred']).detach().to('cpu').numpy()

        # Convert predictions to images
        instance_pred_img = (instance_pred * 255).astype(np.uint8)
        binary_pred_img = (binary_pred * 255).astype(np.uint8)  # Single-channel binary prediction

        # Resize instance_pred_img to match frame size
        instance_pred_img_resized = cv2.resize(instance_pred_img.transpose((1, 2, 0)), (frame_width, frame_height), interpolation=cv2.INTER_LINEAR)
        if len(instance_pred_img_resized.shape) == 3 and instance_pred_img_resized.shape[2] != 1:
            instance_pred_img_resized = cv2.cvtColor(instance_pred_img_resized, cv2.COLOR_BGR2GRAY)
        if len(instance_pred_img_resized.shape) == 2:
            instance_pred_img_rgb = cv2.applyColorMap(instance_pred_img_resized, cv2.COLORMAP_JET)
        else:
            instance_pred_img_rgb = instance_pred_img_resized

        # Apply different thresholds and display results
        for threshold in thresholds:
            _, binary_pred_img_thresholded = cv2.threshold(binary_pred_img, threshold, 255, cv2.THRESH_BINARY)
            binary_pred_img_resized = cv2.resize(binary_pred_img_thresholded, (frame_width, frame_height), interpolation=cv2.INTER_NEAREST)

            # Display the binary output with different thresholds
            cv2.imshow(f'Binary Output (Threshold: {threshold})', binary_pred_img_resized)

            # Break if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # Write the frames to the output videos
        result = cv2.addWeighted(frame, 0.7, instance_pred_img_rgb, 0.3, 0)
        out.write(result)
        out_instance.write(instance_pred_img_resized)
        out_binary.write(binary_pred_img_resized)

    cap.release()
    out.release()
    out_instance.release()
    out_binary.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    # Hard-code paths and parameters here
    video_path = 'Video path'  # Update this with your video path
    model_path = 'best_model.pth'  # Update this with your model path
    resize_height = 256
    resize_width = 512

    process_video(video_path, model_path, resize_height, resize_width)
